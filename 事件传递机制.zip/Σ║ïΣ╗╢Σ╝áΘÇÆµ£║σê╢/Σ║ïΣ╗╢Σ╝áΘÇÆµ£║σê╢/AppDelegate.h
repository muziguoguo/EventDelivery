//
//  AppDelegate.h
//  事件传递机制
//
//  Created by  on 2019/7/25.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

