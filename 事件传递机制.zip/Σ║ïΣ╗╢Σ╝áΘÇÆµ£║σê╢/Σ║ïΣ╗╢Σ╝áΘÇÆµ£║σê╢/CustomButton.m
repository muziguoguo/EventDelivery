//
//  CustomButton.m
//  事件传递机制
//
//  Created by  on 2019/7/25.
//

#import "CustomButton.h"

@implementation CustomButton

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
    if (!self.hidden && self.userInteractionEnabled && self.alpha>0.01) {
        if ([self pointInside:point withEvent:event]) {
            __block UIView *hitView = nil;
            //倒序遍历当前视图中的所有子视图
            [self.subviews enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                //将事件触发坐标转换成子视图中的坐标
                CGPoint subPoint = [self convertPoint:point toView:obj];
                hitView = [obj hitTest:subPoint withEvent:event];
                //遇到可以响应的子视图则停止遍历
                if (hitView) {
                    *stop = YES;
                }
            }];
            if (hitView) {
                return hitView;
            }
            return self;
        }
    }
    return nil;
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event{
    CGFloat x1 = point.x;
    CGFloat y1 = point.y;
    
    CGFloat x2 = self.frame.size.width/2;
    CGFloat y2 = self.frame.size.height/2;
    
    //计算圆内某点到圆心距离
    CGFloat distance = sqrt(pow(x1-x2, 2)+pow(y1-y2, 2));
    
    if (distance<=self.frame.size.width/2) {
        return true;
    }
    return false;
}

@end
