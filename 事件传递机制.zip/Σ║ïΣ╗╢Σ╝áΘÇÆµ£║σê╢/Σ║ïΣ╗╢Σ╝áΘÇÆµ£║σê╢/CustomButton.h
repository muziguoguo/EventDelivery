//
//  CustomButton.h
//  事件传递机制
//
//  Created by  on 2019/7/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

///封装只有圆形区域可以响应点击事件的按钮
@interface CustomButton : UIButton

@end

NS_ASSUME_NONNULL_END
