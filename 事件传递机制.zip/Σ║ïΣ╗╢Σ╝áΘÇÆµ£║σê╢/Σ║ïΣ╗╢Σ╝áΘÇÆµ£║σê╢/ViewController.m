//
//  ViewController.m
//  事件传递机制
//
//  Created by  on 2019/7/25.
//

#import "ViewController.h"
#import "CustomButton.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CustomButton *cusBtn = [[CustomButton alloc] initWithFrame:CGRectMake((self.view.frame.size.width-100)/2, 100, 100, 100)];
    [cusBtn setBackgroundColor:[UIColor orangeColor]];
    [cusBtn addTarget:self action:@selector(clickedCusBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:cusBtn];
}

#pragma mark == 按钮响应事件
- (void)clickedCusBtn:(UIButton *)sender{
    NSLog(@"点中了按钮响应区域。");
}


@end
